package org.jcheck.exceptions;

/**
 *
 * @author Hampus
 */
public class ImplicationFalseError extends Error
{
    public ImplicationFalseError()
    {
    }
    
    public ImplicationFalseError(String message)
    {
        super(message);
    }
}
