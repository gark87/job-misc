package org.jcheck;

import org.junit.Test;
import org.junit.runner.RunWith;
import static org.jcheck.Implication.imply;
import static junit.framework.Assert.fail;
import static junit.framework.Assert.assertTrue;

/**
 * These unit tests are examples of bad properties. It is quite easy
 * to come up with properties that do not hold if one isn't careful.
 */
@RunWith(org.jcheck.runners.JCheckRunner.class)
public class ShouldFailTest
{
    /**
     * Test that reversing a string doesn't give the
     * same string back (which of course is a bad property
     * since it can)
     */
    @Test(expected=AssertionError.class)
    public void notAPropertyOfReverse(String str)
    {
        StringBuffer buff = new StringBuffer(str);

        if (str.equals(buff.reverse().toString())) {
            fail();
        }
    }
    
    /**
     * One might think that adding two numbers together will give a number
     * greater than both of those two numbers...
     */
    @Test(expected=AssertionError.class)
    public void notAPropertyOfAdd(int i, int j)
    {
        assertTrue(i+j > i && i+j > j);
    }
    
    /**
     * One might make an implication which is very hard to
     * satisfy. In such cases one should probably create a
     * special generator.
     */
    @Test(expected=AssertionError.class)
    public void badImplication(double d)
    {
        imply(d > 10.0);
        imply("Must be less than 10.001", d < 10.001);
    }
}
