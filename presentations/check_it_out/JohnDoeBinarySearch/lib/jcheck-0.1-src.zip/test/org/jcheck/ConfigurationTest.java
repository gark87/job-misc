package org.jcheck;

import org.jcheck.annotations.Configuration;
import org.junit.AfterClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertTrue;

@RunWith(org.jcheck.runners.JCheckRunner.class)
public class ConfigurationTest
{
    private int count = 0;
    private static int count2 = 0;
    
    @Test
    @Configuration(tests=3)
    public void configurationSetNumberOfTests(int i)
    {
        count++;
        assertTrue("Should not run more than 3 tests", count < 4);
    }
    
    @Test
    public void configurationDontSetNumberOfTests(int i)
    {
        count2++;
    }
    
    @AfterClass
    public static void configurationDontSetNumberOfTestsCheckIt()
    {
        assertTrue(count2 == 0 || count2 > 3);
    }
}
