package org.jcheck.generator;

import java.util.Random;

public class OnesGen implements Gen<Integer> 
{
    private static final Integer i = 1;
    public Integer arbitrary(Random random,long size)
    {
        return i;
    }
}
