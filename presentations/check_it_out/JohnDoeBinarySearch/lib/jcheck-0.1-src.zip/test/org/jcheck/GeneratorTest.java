package org.jcheck;

import org.jcheck.annotations.Generator;
import org.jcheck.annotations.UseGenerators;
import org.junit.runner.RunWith;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(org.jcheck.runners.JCheckRunner.class)
@Generator(klass = Integer.class, generator = org.jcheck.generator.TwosGen.class)
public class GeneratorTest
{
    @Test
    @UseGenerators({@Generator(generator = org.jcheck.generator.OnesGen.class,
                               klass = int.class)})
    public void testMethodUseGenerator(int i)
    {
        assertEquals("Should be one", 1, i);
    }

    @Test
    @Generator(position = 0, generator = org.jcheck.generator.OnesGen.class)
    public void testMethodGenerator(Integer i)
    {
        assertEquals("Should be one", 1, i.intValue());
    }

    @Test
    public void testClassGenerator(Integer i)
    {
        assertEquals(2, i.intValue());
    }
    
    @Test
    @Generator(klass = int.class, 
               generator = org.jcheck.generator.TwoFourSixGen.class)
    public void testElementGen(int i)
    {
        assertTrue(i == 2 || i == 4 || i == 6);
    }
    
    @Test
    @Generator(klass = int[].class, 
               generator = org.jcheck.generator.SizeTwoArrayGen.class)
    public void testCustomArrayGen(int[] i)
    {
        assertTrue(i.length == 2);
    }
}
