package org.jcheck.generator;

public class TwoFourSixGen extends ElementGen<Integer>
{
    public TwoFourSixGen()
    {
        super(2,4,6);
    }
}
