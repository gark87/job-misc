package org.jcheck.generator;

import java.util.Random;

public class TwosGen implements Gen<Integer> 
{
    private static final Integer i = 2;
    public Integer arbitrary(Random random,long size)
    {
        return i;
    }
}
